/* empty css                       */const n=()=>{};export{n as default};
