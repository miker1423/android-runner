const o=()=>{};export{o as default};
