/* empty css                   */const o=()=>{};export{o as default};
