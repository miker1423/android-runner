import{a as o}from"./ssr-window.esm.db8206e8.js";const e=()=>o();export{e as u};
