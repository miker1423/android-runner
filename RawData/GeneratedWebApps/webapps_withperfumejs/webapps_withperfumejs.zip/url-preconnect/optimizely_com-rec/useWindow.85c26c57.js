import{g as o}from"./ssr-window.esm.db8206e8.js";const t=()=>o();export{t as u};
