
(function() {
    var domain = '.pcmag.com'; var cc = 'NL'; var akcc = 'NL';
    if (cc && document.cookie.indexOf('geoCC') == -1) {
      document.cookie='geoCC='+cc+';path=/;domain='+domain;
      document.cookie='geoCC='+cc+';path=/;domain=.ziffdavisinternational.com';
    }
})();
    
