<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Page Not Found :(</title><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"/><link href="//fonts.googleapis.com/css?family=Merriweather:300,300i,400,400i,700,700i,900,900i|Roboto+Condensed:300,400,700|Roboto:300,400,500,500i,700|Material+Icons" rel="stylesheet"><style>body{
      width: 100%;
      margin: 0;
      -webkit-font-smoothing: antialiased;
      -moz-osx-font-smoothing: grayscale;
    }

   a{
     text-decoration: none;
   }

    .head {
      height: 60px;
      display: flex;
      flex-direction: column;
      justify-content: center;
      max-width: 111.42857142857143rem;
      padding: 0 24px;
    }
    .logo-image {
      height: 25px;
      margin-left: 16px;
      margin-top: 0px;
      width: 241px;
    }
    .main {
      width:100%;
      max-width:1024px;
      margin: 100px auto 90px;
    }

    .main__top, .main__middle, .main__bottom {
      padding: 0px 40px;
    }

    .main__middle {
      margin-top: 48px;
      display: flex;
      flex-direction: row;
      justify-content: space-between;
    }

    .main__bottom {
      margin-top: 48px;
      margin-bottom: 30px;
    }

    .top__title{
      color: #001246;
      font-family: Roboto;
      font-size: 100px;
      font-weight: 900;
      line-height: 117px;
      margin-bottom: 12px;
    }

    .desc{
      color: #000000;
      font-family: Merriweather;
      font-size: 24px;
      font-weight: bold;
      line-height: 35px;
      margin-bottom: 12px;
    }
    .search{
      color: #999999;
      font-family: Roboto;
      font-size: 48px;
      line-height: 57px;
      padding-bottom: 12px;
      border-bottom: 1px solid #000;
      display: flex;
      width: 100%;

    }

   .search::after{
     content:"";
     display: flex;
     flex: 1 1 0;
     justify-content: flex-end;
   }

   .bottom__contents{
     display: flex;
     flex-direction: row;
     flex-wrap: wrap;
     align-items: baseline;

   }

   .bottom__title{
     color: #001246;
     font-family: Roboto;
     font-size: 24px;
     font-weight: bold;
     line-height: 28px;
     padding-top:10px;
     margin-bottom: 40px;
     position: relative;
   }

   .bottom__title::before{
     border-top: 3px solid #FFCA05;
     content: "";
     width: 28px;
     height: 3px;
     top: 0;
     position: absolute;
   }

   .contents__info{
     margin-bottom: 50px;
     display: flex;
     flex-direction: column;
     flex:1 1 0;
     max-width: 265px;
     margin-right: 48px;
   }

   .info__icon {
     width: 265px;
     height: 265px;
     border-radius: 265px;
     background-color:#7f7f7f;
     margin: auto;
     margin-bottom: 20px;
   }

   .info__desc{
     color: #000000;
     font-family: Roboto;
     font-size: 20px;
     line-height: 24px;
     text-align: center;
   }

   @media screen and (max-width: 600px) {
     .head {padding: 0 12px;}
     .main {margin-top: 2px;}
     .search {font-size: 24px;line-height: 32px;}
     .desc {font-size: 20px; line-height: 26px; margin-bottom: 12px;}
     .main__top, .main__middle, .main__bottom {padding: 0 20px;}
     .bottom__title {font-size: 20px;}
     .contents__info {margin: 0 auto 40px;}
     .main__middle {margin-top: 30px;}
     .top__title {font-size: 100px;}
     .logo-image {
      height: 24px;
      margin-left: 4px;
      margin-top: 3px;
      width: 243px;
    }
   }</style></head><body><div class="head"><a class="logo" href="/?module=scmp_favourites_link&pgtype=404"><img src="https://cdn.i-scmp.com/sites/default/files/d8/images/2019/02/15/scmp_logo.png" alt="South China Morning Post" class="logo-image"/></a></div><div class="main"><div class="main__top"><div class="top__title">404</div><div class="top__desc--1 desc">The page you were looking for appears to have moved or never existed.</div><div class="top__desc--2 desc">Try searching for what you're looking for or browse some of our favourites below:</div></div><div class="main__middle"><a class="middle__search search" href="/search?module=scmp_favourites_link&pgtype=404">Search SCMP</a></div><div class="main__bottom"><div class="bottom__title">Stories you may have missed</div><div class="bottom__contents contents"><div class="contents__info info"><a href="/economy/china-economy/article/3197405/chinas-top-legislature-deliberates-new-nominations-leadership-reshuffle-stokes-market-turmoil?module=scmp_favourites_link&pgtype=404"><img class="info__icon" src="https://cdn.i-scmp.com/sites/default/files/styles/250x250/public/d8/images/canvas/2022/10/27/d47fdbf2-84d9-4378-a612-cb87590798f6_9db40d24.jpg?itok=c3tvNI2j&v=1666844596" alt="China’s top legislature convenes to ‘deliberate’ on economic nominations"><div class="info__desc">China’s top legislature convenes to ‘deliberate’ on economic nominations</div></a></div><div class="contents__info info"><a href="/news/china/politics/article/3197419/politburo-newcomer-and-xi-protege-confirmed-chinas-new-propaganda-chief-presenting-summary-20th?module=scmp_favourites_link&pgtype=404"><img class="info__icon" src="https://cdn.i-scmp.com/sites/default/files/styles/250x250/public/d8/images/canvas/2022/10/27/2f0f6ca9-945d-4f51-800e-59a614d3465e_f795c9db.jpg?itok=OII4NHnw&v=1666852403" alt="Politburo newcomer and Xi protégé confirmed as China’s propaganda chief"><div class="info__desc">Politburo newcomer and Xi protégé confirmed as China’s propaganda chief</div></a></div><div class="contents__info info"><a href="/news/china/science/article/3197416/cities-across-china-double-down-covid-19-controls?module=scmp_favourites_link&pgtype=404"><img class="info__icon" src="https://cdn.i-scmp.com/sites/default/files/styles/250x250/public/d8/images/canvas/2022/10/27/c6afb20c-c72a-48a9-a8d3-704a8f636a6d_29bc111d.jpg?itok=mx-3QPOs&v=1666848873" alt="Cities across China double down on Covid-19 controls"><div class="info__desc">Cities across China double down on Covid-19 controls</div></a></div><div class="contents__info info"><a href="/news/hong-kong/hong-kong-economy/article/3197406/hong-kong-finance-chief-paul-chan-gets-covid-middle-east-work-trip-questions-raised-his-return?module=scmp_favourites_link&pgtype=404"><img class="info__icon" src="https://cdn.i-scmp.com/sites/default/files/styles/250x250/public/d8/images/canvas/2022/10/27/b4bb651f-b09a-41c9-9243-94b9c5dbdb54_aeba18bc.jpg?itok=VPMzWeXW&v=1666845895" alt="Hong Kong finance chief Paul Chan gets Covid on Middle East work trip"><div class="info__desc">Hong Kong finance chief Paul Chan gets Covid on Middle East work trip</div></a></div><div class="contents__info info"><a href="/lifestyle/travel-leisure/article/3197391/bali-mind-indonesia-offers-10-year-second-home-visas-if-you-have-us129000-bank?module=scmp_favourites_link&pgtype=404"><img class="info__icon" src="https://cdn.i-scmp.com/sites/default/files/styles/250x250/public/d8/images/canvas/2022/10/27/22cb9cb5-203c-4d72-9490-43118ccd6d7f_e87eeaab.jpg?itok=lQ9ndecJ&v=1666838863" alt="Indonesia lures wealthy tourists to Bali with 10-year second home visas"><div class="info__desc">Indonesia lures wealthy tourists to Bali with 10-year second home visas</div></a></div><div class="contents__info info"><a href="/news/world/united-states-canada/article/3197398/kanye-west-escorted-out-skechers-offices-after-he-arrived-uninvited?module=scmp_favourites_link&pgtype=404"><img class="info__icon" src="https://cdn.i-scmp.com/sites/default/files/styles/250x250/public/d8/images/canvas/2022/10/27/1de5cdbd-f052-42e0-a696-ef096a0d0ebc_44299fb3.jpg?itok=wEnYOfx4&v=1666843241" alt="Kanye West ‘escorted’ out of Skechers offices"><div class="info__desc">Kanye West ‘escorted’ out of Skechers offices</div></a></div></div></div></div><script src="/static/pages/static-bundle.js"></script></body></html>